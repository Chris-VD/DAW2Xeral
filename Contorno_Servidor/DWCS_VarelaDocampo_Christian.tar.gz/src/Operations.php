<?php
require_once("./Post.php");
class Operations
{
    private $conn;
    public function __construct(){
        $this->openConnection();
    }
    public function openConnection()
    {
        // Database configuration (match your docker-compose.yml)
        $host = 'db';          // The service name in docker-compose (not 'localhost')
        $db   = 'mydb';        // Database name
        $user = 'user';        // MySQL username
        $pass = 'userpass';    // MySQL password
        $charset = 'utf8mb4';

        // DSN (Data Source Name)
        $dsn = "mysql:host=$host;dbname=$db;charset=$charset";

        // PDO options for better error handling and performance
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION, // Throw exceptions on errors
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,       // Fetch results as associative arrays
            PDO::ATTR_EMULATE_PREPARES   => false,                  // Use real prepared statements
        ];

        // Create a PDO instance (connect to the database)
        $this->conn = new PDO($dsn, $user, $pass, $options);
    }//openConnection
    public function closeConnection()
    {
        $this->conn = null;
    }

    public function getPost(string $id): Post{
        $sql = "select * from post where id=?";
        $query = $this->conn->prepare($sql);
        $query->execute([ $id ]);
        $post = $query->fetch();
        return new Post($post["id"], $post["title"], $post["contents"]);
    }

    public function addPost(Post $post): bool{
        $sql = "insert into post(title, contents) values(?,?)";
        $query = $this->conn->prepare($sql);
        return $query->execute([ $post->getTitle(), $post->getContents() ]);
    }

    public function getAllPosts():array{
        $sql = "select * from post";
        $query = $this->conn->prepare($sql);
        $query->execute();
        $postList = [];
        while ($postRaw = $query->fetch()){
            $post = $this->getPost($postRaw["id"]);
            $postList[] = $post;
        }
        return $postList;
    }
}//class
