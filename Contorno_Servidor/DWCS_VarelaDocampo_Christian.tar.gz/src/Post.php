<?php declare (strict_types= 1);
    class Post{
        private $id;
        private $title;
        private $contents;

        function __construct(string $id, string $title, string $contents){
            $this->id = $id;
            $this->title = $title;
            $this->contents = $contents;
        }

        public function getId(): string{
            return $this->id;
        }
        public function getTitle(): string{
            return $this->title;
        }
        public function getContents(): string{
            return $this->contents;
        }
    }
?>