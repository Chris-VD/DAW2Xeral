<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Error</title>
</head>
<body>
    <h1>There was an error processing the request!</h1>
    <a href="./new.php">Back to the post forum</a>
</body>
</html>