<?php declare (strict_types= 1);
    require_once "./Operations.php";
    $oper = new Operations();
    $posts = $oper->getAllPosts();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Index</title>
</head>
<body>
    <h1>POSTS</h1>
    <ul>
    <?
        foreach ($posts as $post){
            echo "<li><a href=\"post.php?id=";
            echo $post->getId()."\">";
            echo $post->getTitle()."</a></li>";
        }
    ?>
    </ul>
    <a href="new.php">Add a new post!</a>
</body>
</html>
