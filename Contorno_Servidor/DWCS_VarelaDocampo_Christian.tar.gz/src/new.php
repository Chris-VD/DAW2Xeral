<?php declare (strict_types= 1);
    require_once "./Operations.php";
    function test_input($data) {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }
    $title = $contents = "";
    $titleErr = $contentsErr = "";
    $next = true;
    if (isset($_POST["submit"])){
        if (empty($_POST["title"])){
            $next = false;
            $titleErr = "* Title is mandatory!";
        } else {
            $title = test_input($_POST["title"]);
            if (!preg_match("/^[a-zA-Z-' 0-9]*$/",$title)) {
                $next = false;
                $titleErr = "* Only letters and white space allowed";
            }
        }
        if (empty($_POST["contents"])){
            $next = false;
            $contentsErr = "* Contents are mandatory!";
        } else $contents = test_input($_POST["contents"]);
        if ($next) {
            $oper = new Operations();
            $next = $oper->addPost(new Post("0", $title, $contents));
            header("Location: index.php");
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>New</title>
    <style>
        .err{
            color: red;
        }
    </style>
</head>
<body>
    <h1>ADD A POST</h1>
    <form action="" method="POST">
        <label for="title">Title
            <input type="text" name="title" id="title" value="<?echo $title?>">
            <span class="err"><?echo $titleErr?></span><br>
        </label>
        <label for="contents">Contents
            <textarea name="contents" id="contents" cols="40" rows="5"><?echo $contents?></textarea>
            <span class="err"><?echo $contentsErr?></span><br>
        </label>
        <input type="submit" name="submit" value="Add to the database">
    </form><br>
    <a href="./index.php">Back to main page</a>
</body>
</html>