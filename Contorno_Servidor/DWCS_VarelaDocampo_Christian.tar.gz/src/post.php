<?php declare (strict_types= 1);
    require_once "./Operations.php";
    $oper = new Operations();
    $post = $oper->getPost($_GET["id"]);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Post</title>
</head>
<body>
    <h1>
        <?echo $post->getTitle()?>
    </h1>
    <p>
        <?echo $post->getContents()?>
    </p>
    <a href="./index.php">Back to main page</a>
</body>
</html>