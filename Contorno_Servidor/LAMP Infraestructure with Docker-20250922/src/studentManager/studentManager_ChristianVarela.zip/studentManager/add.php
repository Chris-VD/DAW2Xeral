<?php declare (strict_types = 1);
    require_once "./Operations.php";
    function test_input($data){
        $data = htmlspecialchars(stripslashes(trim($data)));
        return $data;
    }
    if(isset($_POST["send"])){  
        $next = false;
        $student = new Student();
        $student->setDni(test_input($_POST["dni"]));
        $student->setName(test_input($_POST["name"]));
        $student->setSurname(test_input($_POST["surname"]));
        $student->setAge(test_input($_POST["age"]));
        if (!($student->isValid())) header("Location: failure.html");
        else {
            try {
                $oper = new Operations();
                $oper->openConnection();
                $next = $oper->addStudent($student);
            } catch (PDOException $e) {
                echo "Database connection failed: " . $e->getMessage();
                $next = false;
            } finally {
                $oper->closeconnection();
            }
            if ($next) header("Location: success.html");
            else header("Location: failure.html");
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add</title>
</head>
<body>
    <h1>Add Student</h1>
    <form action="" method="POST">
        <label for="dni">DNI: </label>
        <input type="text" name="dni" id="dni"><br>
        <label for="name">Name: </label>
        <input type="text" name="name" id="name"><br>
        <label for="surname">Surname: </label>
        <input type="text" name="surname" id="surname"><br>
        <label for="age">Age: </label>
        <input type="text" name="age" id="age"><br>
        <input type="submit" name="send" value="Add">
    </form>
    <a href="./studentManager.php">Back to the student manager...</a>
</body>
</html>